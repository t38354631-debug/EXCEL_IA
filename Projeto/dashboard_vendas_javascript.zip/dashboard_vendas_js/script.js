const STORAGE_KEY = "dashboard_vendas_registros_v1";
let pedidos = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
let catalogo = new Map();
let monthlyChart, regionChart;

const $ = (id) => document.getElementById(id);
const money = (value) => Number(value || 0).toLocaleString("pt-BR", {style:"currency",currency:"BRL"});
const dateBR = (value) => {
  if (!value) return "";
  const d = new Date(`${value}T00:00:00`);
  return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString("pt-BR");
};
const normalizeDate = (value) => {
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString().slice(0,10);
  if (typeof value === "number" && window.XLSX) {
    const d = XLSX.SSF.parse_date_code(value);
    if (d) return `${d.y}-${String(d.m).padStart(2,"0")}-${String(d.d).padStart(2,"0")}`;
  }
  if (typeof value === "string") {
    const s = value.trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0,10);
    const m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (m) return `${m[3]}-${m[2].padStart(2,"0")}-${m[1].padStart(2,"0")}`;
  }
  return "";
};
function save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(pedidos)); }
function readNumber(value) {
  if (typeof value === "number") return value;
  if (value == null || value === "") return 0;
  const n = Number(String(value).replace(/\./g,"").replace(",",".").replace(/[^\d.-]/g,""));
  return Number.isFinite(n) ? n : 0;
}
function addCatalogProduct(name, price) {
  if (!name) return;
  catalogo.set(String(name).trim(), readNumber(price));
}
function refreshProductOptions() {
  const select = $("produto");
  const current = select.value;
  select.innerHTML = '<option value="">Selecione um produto</option>';
  [...catalogo.keys()].sort().forEach(name => {
    const option = document.createElement("option");
    option.value = name; option.textContent = name;
    select.appendChild(option);
  });
  if ([...catalogo.keys()].includes(current)) select.value = current;
}
function render() {
  const total = pedidos.reduce((sum,p) => sum + readNumber(p.total), 0);
  const units = pedidos.reduce((sum,p) => sum + readNumber(p.quantidade), 0);
  $("kpiRevenue").textContent = money(total);
  $("kpiOrders").textContent = pedidos.length.toLocaleString("pt-BR");
  $("kpiUnits").textContent = units.toLocaleString("pt-BR");
  $("kpiTicket").textContent = money(pedidos.length ? total/pedidos.length : 0);
  $("recordCount").textContent = `${pedidos.length} registro(s)`;
  $("dataStatus").textContent = pedidos.length ? `${pedidos.length} registros carregados` : "Aguardando importação da planilha";
  renderTable($("searchInput").value);
  renderCharts();
}
function renderTable(filter="") {
  const body = $("ordersBody");
  const term = filter.toLocaleLowerCase("pt-BR");
  const rows = pedidos.filter(p => [p.pedido,p.regiao,p.estado,p.produto].join(" ").toLocaleLowerCase("pt-BR").includes(term));
  body.innerHTML = "";
  if (!rows.length) {
    body.innerHTML = `<tr><td colspan="9" class="empty">${pedidos.length ? "Nenhum registro encontrado." : "Importe sua planilha Excel para visualizar os registros."}</td></tr>`;
    return;
  }
  rows.slice().sort((a,b) => Number(b.pedido)-Number(a.pedido)).forEach(p => {
    const tr = document.createElement("tr");
    [p.pedido,dateBR(p.data),p.regiao,p.estado,p.produto,p.quantidade,money(p.valorUnitario),money(p.frete),money(p.total)].forEach(v => {
      const td = document.createElement("td"); td.textContent = v ?? ""; tr.appendChild(td);
    });
    body.appendChild(tr);
  });
}
function renderCharts() {
  const byMonth = new Map(), byRegion = new Map();
  pedidos.forEach(p => {
    const month = p.data ? p.data.slice(0,7) : "Sem data";
    byMonth.set(month,(byMonth.get(month)||0)+readNumber(p.total));
    const region = p.regiao || "Não informado";
    byRegion.set(region,(byRegion.get(region)||0)+readNumber(p.total));
  });
  const months = [...byMonth.keys()].sort();
  const monthLabels = months.map(m => {
    if (m === "Sem data") return m;
    const [y,mm] = m.split("-");
    return new Date(Number(y),Number(mm)-1,1).toLocaleDateString("pt-BR",{month:"short",year:"2-digit"});
  });
  if (monthlyChart) monthlyChart.destroy();
  monthlyChart = new Chart($("monthlyChart"), {
    type:"bar",
    data:{labels:monthLabels,datasets:[{label:"Faturamento",data:months.map(m=>byMonth.get(m)),backgroundColor:"#3985b8",borderRadius:5}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{callback:v=>"R$ "+Number(v).toLocaleString("pt-BR")}},x:{grid:{display:false}}}}
  });
  if (regionChart) regionChart.destroy();
  regionChart = new Chart($("regionChart"), {
    type:"doughnut",
    data:{labels:[...byRegion.keys()],datasets:[{data:[...byRegion.values()],backgroundColor:["#2878ad","#69a6c9","#9bbdce","#e2a85b","#52718b","#9aabb9"]}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:"bottom",labels:{boxWidth:10,font:{size:10}}}}}
  });
}
function mapExcelRow(row) {
  const pedido = readNumber(row["Pedido"]);
  const quantidade = readNumber(row["Quantidade"]);
  const valorUnitario = readNumber(row["Valor Unitário"]);
  const frete = readNumber(row["Frete"]);
  const totalInformado = readNumber(row["Total"]);
  return {
    pedido, regiao:row["Região"] || "", estado:String(row["Estado"] || "").toUpperCase(),
    produto:row["Produtos"] || "", data:normalizeDate(row["Data"]),
    quantidade, valorUnitario, frete,
    total:totalInformado || quantidade*valorUnitario+frete
  };
}
$("excelInput").addEventListener("change", async (event) => {
  const file = event.target.files[0]; if (!file) return;
  try {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer,{type:"array",cellDates:true});
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet,{defval:""});
    pedidos = rows.filter(r => r["Pedido"] !== "").map(mapExcelRow).filter(p => p.pedido);
    // As colunas auxiliares Produtos.1 e Valor são interpretadas como catálogo, quando preenchidas.
    rows.forEach(r => addCatalogProduct(r["Produtos.1"],r["Valor"]));
    pedidos.forEach(p => addCatalogProduct(p.produto,p.valorUnitario));
    save(); refreshProductOptions(); render();
    $("formMessage").textContent = `Planilha "${file.name}" importada com sucesso.`;
  } catch (error) {
    alert("Não foi possível ler a planilha. Verifique se o arquivo está no formato Excel (.xlsx ou .xls).");
    console.error(error);
  }
  event.target.value = "";
});
function updatePreview() {
  const qtd = readNumber($("quantidade").value), unit = readNumber($("valorUnitario").value), frete = readNumber($("frete").value);
  $("totalPreview").textContent = money(qtd*unit+frete);
}
["quantidade","valorUnitario","frete"].forEach(id => $(id).addEventListener("input",updatePreview));
$("produto").addEventListener("change",() => {
  const price = catalogo.get($("produto").value);
  if (price !== undefined) $("valorUnitario").value = price;
  updatePreview();
});
$("orderForm").addEventListener("reset",() => setTimeout(() => { $("totalPreview").textContent=money(0); $("formMessage").textContent=""; },0));
$("orderForm").addEventListener("submit",(event) => {
  event.preventDefault();
  const pedido = readNumber($("pedido").value);
  if (pedidos.some(p => Number(p.pedido) === pedido)) {
    $("formMessage").textContent = "Este número de pedido já existe. Informe outro número.";
    return;
  }
  const quantidade = readNumber($("quantidade").value);
  const valorUnitario = readNumber($("valorUnitario").value);
  const frete = readNumber($("frete").value);
  const novo = {
    pedido, data:$("data").value, regiao:$("regiao").value,
    estado:$("estado").value.trim().toUpperCase(), produto:$("produto").value,
    quantidade, valorUnitario, frete, total:quantidade*valorUnitario+frete
  };
  pedidos.push(novo); addCatalogProduct(novo.produto,novo.valorUnitario);
  save(); refreshProductOptions(); render();
  $("formMessage").textContent = `Pedido ${pedido} cadastrado com sucesso.`;
  $("orderForm").reset(); $("pedido").value = Math.max(0,...pedidos.map(p=>Number(p.pedido)||0))+1;
});
$("searchInput").addEventListener("input",e => renderTable(e.target.value));
$("exportBtn").addEventListener("click",() => {
  if (!pedidos.length) { alert("Importe ou cadastre pelo menos um pedido antes de exportar."); return; }
  const output = pedidos.map(p => ({
    "Pedido":p.pedido,"Região":p.regiao,"Estado":p.estado,"Produtos":p.produto,
    "Data":p.data,"Quantidade":p.quantidade,"Valor Unitário":p.valorUnitario,
    "Frete":p.frete,"Total":p.total
  }));
  const ws = XLSX.utils.json_to_sheet(output);
  const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,"Vendas");
  XLSX.writeFile(wb,"base_vendas_atualizada.xlsx");
});
$("data").value = new Date().toISOString().slice(0,10);
$("pedido").value = Math.max(1000,...pedidos.map(p=>Number(p.pedido)||0))+1;
render();
